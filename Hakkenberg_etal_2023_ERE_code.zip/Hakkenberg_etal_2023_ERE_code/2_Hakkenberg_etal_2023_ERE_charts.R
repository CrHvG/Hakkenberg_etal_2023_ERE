# Code for charts for Hakkenberg et al. (In Review) ERE. May 10, 2023
# chrishakkenberg@gmail.com

# fig 3. alpha div across scales - trees and plants -------

  plots_1pred<-read.csv("...") # csv output from 1_Hakkenberg_etal_2023_analyses.R #2

  plots_1pred$myscale <- as.factor(plots_1pred$myscale)
  plots_1pred <- plots_1pred[plots_1pred$myscale!=100,]
  plots_1pred$myscale <- as.factor(plots_1pred$myscale)
  plots_1pred$myscale <- factor(plots_1pred$myscale, levels = c(10,12.5, 25,37.5,50,200,400,700,1100,1600,2200,2900,3700,4600,5600))
  levels(plots_1pred$myscale)[1] <- "basePlot"
  NEON_p_vs_c <- plots_1pred[which(plots_1pred$sensor%in% c("NEON","GEDI")),]

  NEON_p_vs_c$subsets <- paste(NEON_p_vs_c$sensor,NEON_p_vs_c$myagg)
  NEON_p_vs_c$subsets <- as.factor(NEON_p_vs_c$subsets)
  levels(NEON_p_vs_c$subsets) <- c("GEDI mean" ,"GEDI sd","ALS census")
  NEON_p_vs_c$subsets <- factor(NEON_p_vs_c$subsets, levels = c("ALS census","GEDI mean" ,"GEDI sd"))

  NEON_p_vs_c$myagg <- as.factor(NEON_p_vs_c$myagg)  
  NEON_p_vs_c$myagg <- factor(NEON_p_vs_c$myagg, levels = levels(NEON_p_vs_c$myagg))
  levels(NEON_p_vs_c$myagg) <- c("mean", "sd")

  lidar_vars<-c("dim_tPAI","dim_max","config_PAIb2","config_VDRPAI", "hetero_H1m","hetero_J")
  NEON_p_vs_c <- NEON_p_vs_c[which(NEON_p_vs_c$lidar_var%in%lidar_vars),] 
  
  NEON_p_vs_c$lidar_var <- as.factor(NEON_p_vs_c$lidar_var)
  NEON_p_vs_c$lidar_var <- factor(NEON_p_vs_c$lidar_var, levels = c("dim_max","dim_tPAI","hetero_H1m","hetero_J","config_PAIb2","config_VDRPAI"))
  levels(NEON_p_vs_c$lidar_var) <- c("H[max]","tPAI","FHD","H['J']","PAI['b2']","VDR")

  NEON_p_vs_c$type <- str_split(NEON_p_vs_c$div_var,"_",simplify=T)[,2]
  NEON_p_vs_c$type <- as.factor(NEON_p_vs_c$type)

  NEON_p_vs_c_Q2a <- NEON_p_vs_c[NEON_p_vs_c$div_var%in%c("plant_SR_400","plant_D_400","tree_SR_400","tree_D_400"),]
  NEON_p_vs_c_Q2a$div_var <- as.factor(NEON_p_vs_c_Q2a$div_var)
  levels(NEON_p_vs_c_Q2a$div_var) <- c("plant['D']","plant['alpha']","tree['D']","tree['alpha']")
  NEON_p_vs_c_Q2a$div_var <- factor(NEON_p_vs_c_Q2a$div_var , levels = c("tree['alpha']","tree['D']","plant['alpha']","plant['D']"))

    NEON_p_vs_c_Q2a <- NEON_p_vs_c_Q2a[NEON_p_vs_c_Q2a$div_var%in% c("plant['alpha']","tree['alpha']") ,] 

  pdf("..fig3.pdf",height=6,width=7)

     ggplot(NEON_p_vs_c_Q2a,aes(x=factor(myscale),y=Value, group=subsets,color=subsets,fill=sig,shape=sig)) + 
          facet_grid(rows = vars(lidar_var),cols = vars(div_var),scales = "fixed",space = "fixed", shrink = TRUE,labeller = label_parsed) + 
          geom_pointrange(aes(ymin = lCI, ymax = hCI),alpha=1,size=.3,position=position_dodge(width=0.5)) +
            geom_vline(xintercept=5.5) +
            geom_hline(yintercept=0) +
          scale_shape_manual(values = c(21,19)) +
          scale_colour_manual(values=c("#39B600","#6077c0","#cd7700")) +
          scale_fill_manual(values = c('grey98',"red")) +
          ylab(expression(beta[1])) +
          xlab("spatial scales (radius in m)") +
          guides(shape = "none",fill="none",color=guide_legend(nrow = 1,override.aes=list(fill=NA))) +
          my_theme(mycolor_background="grey98",mycolor_elements="grey60",mycolor_text="black",plot_background="white") +
          theme(axis.text.x = element_text(angle = 45, vjust = .95, hjust=.9,size = size_tmp),
                axis.text.y = element_text(size = size_tmp),
                            axis.title.x=element_text(family="Helvetica",size=size_tmp),
                            axis.title.y=element_text(family="Helvetica",size=size_tmp+1),
                            plot.title = element_text(size=size_tmp+1,vjust=1),
                            plot.margin = unit(c(0.2, 0.2, 0.2, 0.2), "cm"),
                            legend.margin=margin(0,5,2,5),
                            legend.box.margin=margin(-1,-10,-10,-10),
                            legend.position='top',
                            legend.title=element_blank(),
                            strip.text = element_text(size = size_tmp),
                            legend.text.align = 0,
                            legend.key = element_rect(size = 1),
                            legend.spacing.x = unit(.1,"cm"))
    dev.off()
    
# fig. 4 regional ------
  
  rm(list=ls())
  plots_regional<-read.csv("...") # csv output from 1_Hakkenberg_etal_2023_analyses.R #3
  
  plots_regional <- plots_regional[which(plots_regional$myscale!=100),]
  levels(plots_regional$myscale)
  plots_regional$myscale <- factor(plots_regional$myscale, levels = c(10,12.5, 25,37.5,50,200,400,700,1100,1600,2200,2900,3700,4600,5600))
  levels(plots_regional$myscale)[1] <- "basePlot"
  
  NEON_p_vs_c <- plots_regional[which(plots_regional$sensor%in% c("NEON","GEDI")),]
  NEON_p_vs_c$myscale[is.na(NEON_p_vs_c$myscale)]
 
  NEON_p_vs_c$sensor <- as.factor(NEON_p_vs_c$sensor)
  levels(NEON_p_vs_c$sensor) <- c("GEDI","ALS")

  NEON_p_vs_c$subsets <- paste(NEON_p_vs_c$sensor,NEON_p_vs_c$ecoregion)
  NEON_p_vs_c$subsets <- as.factor(NEON_p_vs_c$subsets)
  NEON_p_vs_c$subsets <- factor(NEON_p_vs_c$subsets, levels = rev(levels(NEON_p_vs_c$subsets)))

  NEON_p_vs_c$lidar_var <- as.factor(NEON_p_vs_c$lidar_var)
  
  NEON_p_vs_c$lidar_var <- factor(NEON_p_vs_c$lidar_var, levels = c("dim_max","dim_tPAI","hetero_H1m","hetero_J","config_PAIb2","config_VDRPAI"))
  levels(NEON_p_vs_c$lidar_var) <- c("H[max]","tPAI","FHD","H['J']","PAI['b2']","VDR")

  NEON_p_vs_c$div <- as.factor(NEON_p_vs_c$div)
  NEON_p_vs_c$div <- factor(NEON_p_vs_c$div, levels = rev(levels(NEON_p_vs_c$div)))

  levels(NEON_p_vs_c$div) <- c("tree['alpha']","tree['D']","plant['alpha']","plant['D']")
  
  size_tmp<-10
  
  gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
  }

  NEON_regions <- NEON_p_vs_c[NEON_p_vs_c$div%in% c("plant['alpha']","tree['alpha']") ,]  # & NEON_p_vs_c$ecoregion!="Tropical Wet Forests"
  unique(NEON_p_vs_c$div)
  NEON_regions$ecoregion <- as.factor(NEON_regions$ecoregion)
  colorBlindBlack8  <- c("#D55E00","#39B600", "#E69F00", "#00B8E7", "#6c71c4","#E76BF3") # , "#E76BF3"
  
  levels(NEON_regions$ecoregion)[1] <- "Desert"

    pdf("/...fig4.pdf",height=6.5,width=8)

      ggplot(NEON_regions,aes(x=myscale,y=Value, group=subsets,color=ecoregion,fill=sig,shape=sig)) + 
          facet_grid(cols = vars(div), rows = vars(lidar_var),scales="free",labeller = label_parsed) + 
          geom_pointrange(aes(ymin = lCI, ymax = hCI),alpha=1,size=.5,position=position_dodge(width=0.7)) +
          geom_vline(xintercept=5.5) +
          geom_hline(yintercept=0) +
          scale_color_manual(values=colorBlindBlack8) + #gg_color_hue(6) 
          scale_shape_manual(values = c(21,16)) +
          scale_fill_manual(values = c('grey98',"red")) +
          ylab(expression(beta[1])) +
          xlab("spatial scales (radius in m)") +
          guides(shape = "none",fill="none",color=guide_legend(nrow = 1,override.aes=list(fill=NA))) +
          my_theme(mycolor_background="grey98",mycolor_elements="grey60",mycolor_text="black",plot_background="white") +
          theme(axis.text.x = element_text(angle = 45, vjust = .95, hjust=.9,size = size_tmp),
                axis.text.y = element_text(size = size_tmp+1),
                            axis.title=element_text(family="Helvetica",size=size_tmp),
                            plot.title = element_text(size=size_tmp+1,vjust=1),
                            plot.margin = unit(c(0.2, 0.2, 0.2, 0.2), "cm"),
                            legend.margin=margin(0,5,2,5),
                            legend.box.margin=margin(-1,-10,-10,-10),
                            legend.position='top',
                            legend.title=element_blank(),
                            strip.text = element_text(size = size_tmp-1),
                            legend.text.align = 0,
                            legend.key = element_rect(size = 1),
                            legend.spacing.x = unit(.1,"cm"))
    dev.off()
  
# fig_5 beta gamma----------
    
  site_results<-read.csv("...") # csv output from 1_Hakkenberg_etal_2023_analyses.R #1
  site_results$siteagg<-as.factor(unlist(lapply(lapply(str_split(site_results$pred_var, "_"), function(x) {x[3]}),paste, collapse = "_")))
  site_results$category<-as.factor(unlist(lapply(lapply(str_split(site_results$pred_var, "_"), function(x) {x[1]}),paste, collapse = "_")))
  site_results$subcat <- paste0(str_split(site_results$pred_var,"_",simplify=T)[,1],"_",str_split(site_results$pred_var,"_",simplify=T)[,2])
  
  lidar_vars<-c("dim_tPAI","dim_max","config_PAIb2","config_VDRPAI", "hetero_H1m","hetero_J")
  site_results <- site_results[which(site_results$subcat%in%lidar_vars),] 
  site_results$subcat <- as.factor(site_results$subcat)

  site_results$subcat <- factor(site_results$subcat, levels = rev(c("dim_max","dim_tPAI","hetero_H1m","hetero_J","config_PAIb2","config_VDRPAI")))
  levels(site_results$subcat) <- rev(c("H[max]","tPAI","FHD","H['J']","PAI['b2']","VDR"))
  
  best_div_vars<-c("tree_site_gamma_SR","tree_site_beta_BArep","plant_site_beta_PArep","plant_site_gamma_SR") #tree_SR_400_sitemean, plant_SR_400_sitemean

  site_results3<-site_results[site_results$div_var %in% best_div_vars,]

  site_results3$div_var <- as.factor(site_results3$div_var)
  levels(site_results3$div_var) <- c("plant['beta']", "plant['gamma']", "tree['beta']", "tree['gamma']")
  site_results3$div_var <- factor(site_results3$div_var, levels = c( "tree['beta']", "tree['gamma']","plant['beta']", "plant['gamma']"))
  
  site_results3$siteagg <- as.factor(site_results3$siteagg)
  levels(site_results3$siteagg) <- c("mean","cv")
  site_results3$siteagg <- factor(site_results3$siteagg, levels = c("mean","cv"))

  site_results3[site_results3$sig=="nonsig","chartR2"]<-""
  site_results3[site_results3$sig=="sig","chartR2"]<-paste0("R2=",round(as.numeric(site_results3[site_results3$sig=="sig","GLS_R2_1p"]),2))

    site_results3$sensor <- as.factor(site_results3$sensor)
  levels(site_results3$sensor) <- c("GEDI","ALS")
  
    site_results3$sensor <- factor(site_results3$sensor, levels = c("ALS","GEDI"))
    
  site_results3$vj <- NA
  site_results3[site_results3$sensor=="NEON","vj"]<-1
  site_results3[site_results3$sensor=="GEDI","vj"]<-0
  
    size_tmp<-10
  color_map <- c("GEDI" = "#E69F00", "ALS" = "#56B4E9")

tmp_plot <- ggplot(site_results3, aes(x = mCI,y=subcat,colour=factor(sensor),fill=factor(sig),shape=factor(sig))) +
                  geom_vline(xintercept = 0, linetype = "longdash")  +
                  geom_pointrange(aes(xmin = lCI, xmax = hCI),alpha=1,size=.5,position=position_dodge(width=0.7)) +
                  guides(fill="none",shape="none",colour = guide_legend(override.aes = list(shape =c(16),colour=color_map))) +
                  facet_grid(rows = vars(siteagg),cols = vars(div_var), scales="free",labeller = label_parsed) +
                  scale_shape_manual(values = c(21,16)) +  
                  scale_fill_manual(values = c('grey98',"red")) +
                  scale_y_discrete(labels = scales::parse_format()) +
                  scale_colour_manual(values=color_map) +
                  my_theme(mycolor_background="grey98",mycolor_elements="grey60",mycolor_text="black",plot_background="white") +
                  ylab("") +  xlab(expression(beta[1])) +
                  theme(axis.text.x=element_text(angle=35,size=size_tmp-1),
                        axis.text.y=element_text(angle=0,size=size_tmp+1),
                        axis.title.x=element_text(angle=0,size=size_tmp+1),
                        axis.title.y=element_text(family="Helvetica",size=size_tmp+1),
                        plot.title = element_text(size=size_tmp+1,vjust=2),
                        plot.margin = unit(c(0.2, 0.2, 0.2, 0.2), "cm"),
                        legend.title=element_blank(),
                        legend.spacing.x = unit(0, 'cm'),
                        legend.position=c(0,.94),
                        legend.justification=c(0,1),
                        legend.background = element_blank(),
                        legend.box.background = element_rect(colour = "grey60"),
                        legend.spacing.y = unit(-.1, "mm"),
                        legend.key = element_rect(colour = 'transparent', fill = 'transparent'),
                        legend.key.size = unit(0.5, "cm"),
                        legend.key.height = unit(-0.2, "cm"),
                        legend.text.align = 0,
                        legend.text=element_text(size=size_tmp-1)) 
                               
  pdf(paste0("...fig.pdf"),height=4,width=9)
  print(tmp_plot)
  dev.off()
  
  
# Fig 6 REA breakpoint ------

  sv_in <- read.csv("...GEDI_semivar.csv")
  sv_in$siteID <- substr(sv_in$plotID,1,4)
  sv_in$sv_range[sv_in$sv_range>5600]<-NA
  
  sv_in2 <- aggregate(.~lidar_var+siteID,data= sv_in[,-1,],FUN=mean) 
  sv_in2$lidar_var <- as.factor(sv_in2$lidar_var)
  sv_in2 <- sv_in2[which(sv_in2$lidar_var%in% c("dim_tPAI","dim_max","config_PAIb2","config_VDRPAI", "hetero_H1m","hetero_J")),]
  sv_in2$lidar_var <- factor(sv_in2$lidar_var, levels = rev(c("dim_max","dim_tPAI","hetero_H1m","hetero_J","config_PAIb2","config_VDRPAI")))
  levels(sv_in2$lidar_var) <- rev(c("H[max]","tPAI","FHD","H['J']","PAI['b2']","VDR"))
  
  sites<-read.csv("...NEON_site_lle.csv")
  
  sv_in3 <- merge(sv_in,sites,all.x=T,by="siteID")
  sv_in4 <- aggregate(.~epa_merge+lidar_var,data= sv_in3[,c("lidar_var","sv_range","epa_merge")],FUN=median)
  sv_in4$epa_merge <- as.factor(sv_in4$epa_merge)
  sv_in4<-sv_in4[sv_in4$lidar_var%in%c("dim_max","dim_tPAI","hetero_H1m","hetero_J","config_PAIb2","config_VDRPAI"),]
  levels(sv_in4$epa_merge) <- c('D', 'EF','GP','NF', 'NWF',"T")
  sv_in4$lidar_var <- as.factor(sv_in4$lidar_var)
  sv_in4$lidar_var <- factor(sv_in4$lidar_var, levels = c("dim_max","dim_tPAI","hetero_H1m","hetero_J","config_PAIb2","config_VDRPAI"))
  levels(sv_in4$lidar_var) <- c("H[max]","tPAI","FHD","H['J']","PAI['b2']","VDR")
  
  colorBlindBlack8  <-   c("#D55E00","#39B600", "#E69F00", "#0072B2", "#6c71c4","#E76BF3")
  
  size_tmp<-9
  fig_6 <- ggplot(sv_in2, aes(sv_range, factor(lidar_var))) +
                my_theme(mycolor_background="grey98",mycolor_elements="grey60",mycolor_text="black",plot_background="white",base_size=9) +
                geom_violin(fill="grey80",draw_quantiles = c(0.5),trim=T) +
                scale_y_discrete(labels = scales::parse_format()) +
                xlab("REA breakpoint (m)") + 
                geom_label_repel(data = sv_in4, aes(x = sv_range, y = lidar_var, label = epa_merge,fill = epa_merge),min.segment.length = 0,label.size = NA,segment.color="black",color="grey98",size=2,nudge_x=0.1,max.overlaps=Inf) +
                geom_point(data = sv_in4,size=1, aes(x = sv_range, y = lidar_var,color = epa_merge),inherit.aes=F) +
                scale_fill_manual(values=c(colorBlindBlack8),labels=c('Deserts (D)', 'Eastern Forests (EF)','Great Plains (GP)','Northern Forest (NF)', 'NW Forests (NWF)',"Tropics (T)")) +
                guides(color="none",fill = guide_legend(nrow = 1,override.aes = aes(label = ""))) +
                theme(axis.text.y=element_text(size=size_tmp-1,hjust=1),
                      axis.text.x=element_text(size=size_tmp-1),
                      axis.title.y=element_blank(),
                      plot.title = element_text(size=size_tmp+1,vjust=1),
                            plot.margin = unit(c(0.2, 0.2, 0.2, 0.2), "cm"),
                            legend.margin=margin(2,5,2,5),
                            #legend.box.margin=margin(-1,-10,-10,-10),
                            legend.position='top',
                      legend.direction="horizontal",
                            legend.title=element_blank(),
                            strip.text = element_text(size = size_tmp-1),
                            legend.text.align = 0,
                            legend.key = element_rect(size = 1),
                            legend.spacing.x = unit(.1,"cm"))
  
  pdf("...fig6.pdf",height=3.5,width=7)
  fig_6
  dev.off()
  
# Figs 7a-c comp   ----------
    
    allplots<-read.csv("...") # csv output from 1_Hakkenberg_etal_2023_analyses.R #2
    allplots$subset <- "(all plots)"
    plots_1pred <- allplots
    size_tmp <- 9
    
    lidar_vars<-c("dim_tPAI","config_PAIb2", "hetero_H1m")
    plots_1pred <- plots_1pred[which(plots_1pred$lidar_var %in% lidar_vars),]
    plots_1pred$lidar_var <- as.factor(plots_1pred$lidar_var)
    plots_1pred$lidar_var <- factor(plots_1pred$lidar_var, levels = c("dim_tPAI","hetero_H1m","config_PAIb2"))
    levels(plots_1pred$lidar_var) <- c("tPAI","FHD","PAI['b2']")

    plots_1pred <- plots_1pred[which(plots_1pred$myagg=="mean"),] 
    plots_1pred$myscale <- factor(plots_1pred$myscale, levels = c(10,12.5, 25,37.5,50,100,200,400,700,1100,1600,2200,2900,3700,4600,5600))
    levels(plots_1pred$myscale) [1] <- "basePlot"
  
    NEON_p_vs_c <- plots_1pred[which(!plots_1pred$sensor%in% "NEON"),]
    NEON_p_vs_c$sensor <- as.factor(NEON_p_vs_c$sensor)
    NEON_p_vs_c$sensor <- factor(NEON_p_vs_c$sensor, levels = c("GEDI","NEON_in_GEDI","NEON_clust_diff","NEON_clust_same"))
    levels(NEON_p_vs_c$sensor) <- c("GEDI samples","GEDI-coincident ALS","Dispersed, dense ALS","Dispersed, sparse ALS")
    

    NEON_p_vs_c <- NEON_p_vs_c[NEON_p_vs_c$div_var%in%c("tree_SR_400"),]
    NEON_p_vs_c$div_var <- as.factor(NEON_p_vs_c$div_var)

    gg_color_hue <- function(n) {
                              hues = seq(15, 375, length = n + 1)
                              hcl(h = hues, l = 65, c = 100)[1:n]
                            }
 # 7a   
    NEON_p_vs_c2 <- NEON_p_vs_c[NEON_p_vs_c$sensor%in%c("GEDI samples","GEDI-coincident ALS"),]
    levels(NEON_p_vs_c2$sensor)

     GEDI_ALS_plot <-   ggplot(NEON_p_vs_c2,aes(x=myscale,y=Value, group=sensor,color=sensor,fill=sig,shape=sig)) + 

                        facet_grid(rows = vars(lidar_var), scales="free",labeller = label_parsed) + 
                        geom_errorbar(aes(ymin=lCI, ymax=hCI), width=0,show.legend=FALSE,linetype=1,alpha=1,size=.7,position=position_dodge(width=0.5)) +
                        geom_point(size=1.5,position=position_dodge(width=0.5)) +  
                        geom_hline(yintercept=0) +
                        scale_shape_manual(values = c(21,16)) +
                        scale_colour_manual(values=c(gg_color_hue(6)[c(1,3)])) +
                        scale_fill_manual(values = c('grey98',"red")) +
                        ylab(expression(beta[1])) +
                        xlab("spatial scales (radius in m)") +
                        guides(shape = "none",fill="none",color=guide_legend(override.aes=list(fill=NA))) +
                        my_theme(mycolor_background="grey98",mycolor_elements="grey60",mycolor_text="black",plot_background="white") +
                        theme(axis.text.x = element_text(angle = 75, vjust = 1, hjust=1,size = size_tmp-2),
                            axis.text.y = element_text(size = size_tmp-2),
                            axis.title.x=element_blank(),
                            axis.title.y=element_text(family="Helvetica",size=size_tmp+1),
                            plot.title = element_text(size=size_tmp+1,vjust=1),
                            plot.margin = unit(c(0.2, 0.2, 0.2, 0.2), "cm"),
                            legend.title=element_blank(),
                            legend.spacing.x = unit(0, 'cm'),
                            legend.position=c("top"),
                            legend.background = element_blank(),
                            strip.text = element_text(size = size_tmp-1),
                            legend.box.background = element_rect(colour = "grey60"),
                            legend.spacing.y = unit(-.1, "mm"),
                            legend.key = element_rect(colour = 'grey98', fill = 'grey98'),
                            legend.key.size = unit(0.5, "cm"),
                            legend.key.height = unit(0, "cm"),
                            legend.text.align = 0,
                                legend.margin=margin(2,2,2,2),
                                  legend.box.spacing = unit(3, "pt"),
                                  legend.box.margin=margin(0,0,0,0),
                            legend.text=element_text(size=size_tmp-2))

  #7b 
     NEON_p_vs_c3 <- NEON_p_vs_c[NEON_p_vs_c$sensor%in%c("GEDI-coincident ALS","Dispersed, sparse ALS"),]

              density_plot <- ggplot(NEON_p_vs_c3,aes(x=myscale,y=Value, group=sensor,color=sensor,fill=sig,shape=sig)) + 
                              facet_grid(rows = vars(lidar_var),scales="free",labeller = label_parsed) + 
                              geom_errorbar(aes(ymin=lCI, ymax=hCI), width=0,show.legend=FALSE,linetype=1,alpha=1,size=.7,position=position_dodge(width=0.5)) +
                              geom_point(size=1.5,position=position_dodge(width=0.5)) +  
                              geom_hline(yintercept=0) +
                              scale_shape_manual(values = c(21,16)) +
                              scale_colour_manual(values=c(gg_color_hue(6)[c(3,5)])) +
                              scale_fill_manual(values = c('grey98',"red")) +
                              ylab(expression(beta[1])) +
                              xlab("spatial scales (radius in m)") +
                              guides(shape = "none",fill="none",color=guide_legend(override.aes=list(fill=NA))) +
                              my_theme(mycolor_background="grey98",mycolor_elements="grey60",mycolor_text="black",plot_background="white") +
                              theme(axis.text.x = element_text(angle = 75, vjust = 1, hjust=1,size = size_tmp-2),
                                  axis.text.y = element_blank(),
                                  axis.title.x=element_text(family="Helvetica",size=size_tmp+1),
                                  axis.title.y=element_blank(),
                                  plot.title = element_text(size=size_tmp+1,vjust=1),
                                  plot.margin = unit(c(0.2, 0.2, 0.2, 0.2), "cm"),
                                  legend.title=element_blank(),
                                  legend.spacing.x = unit(0, 'cm'),
                                  legend.position=c("top"),
                                  legend.background = element_blank(),
                                  strip.text = element_text(size = size_tmp-1),
                                  legend.box.background = element_rect(colour = "grey60"),
                                  legend.spacing.y = unit(-.1, "mm"),
                                  legend.key = element_rect(colour = 'grey98', fill = 'grey98'),
                                  legend.key.size = unit(0.5, "cm"),
                                  legend.key.height = unit(0, "cm"),
                                  legend.text.align = 0,
                                      legend.margin=margin(2,2,2,2),
                                  legend.box.spacing = unit(3, "pt"),
                                  legend.box.margin=margin(0,0,0,0),
                                  legend.text=element_text(size=size_tmp-2))
          
  #7c
    NEON_p_vs_c4 <- NEON_p_vs_c[NEON_p_vs_c$sensor%in%c("Dispersed, dense ALS","Dispersed, sparse ALS"),]
    NEON_p_vs_c4$sensor <- factor(NEON_p_vs_c4$sensor, levels = c("Dispersed, sparse ALS","Dispersed, dense ALS"))

    linear_dispersed_plot <-  ggplot(NEON_p_vs_c4,aes(x=myscale,y=Value, group=sensor,color=sensor,fill=sig,shape=sig)) + 
                              facet_grid(rows = vars(lidar_var),scales="free",labeller = label_parsed) + 
                              geom_errorbar(aes(ymin=lCI, ymax=hCI), width=0,show.legend=FALSE,linetype=1,alpha=1,size=.7,position=position_dodge(width=0.5)) +
                              geom_point(size=1.5,position=position_dodge(width=0.5)) +  
                              geom_hline(yintercept=0) +
                              scale_shape_manual(values = c(21,16)) +
                              scale_colour_manual(values=c(gg_color_hue(6)[c(5,2)])) +
                              scale_fill_manual(values = c('grey98',"red")) +
                              ylab(expression(beta[1])) +
                              xlab("spatial scales (radius in m)") +
                              guides(shape = "none",fill="none",color=guide_legend(override.aes=list(fill=NA))) +
                              my_theme(mycolor_background="grey98",mycolor_elements="grey60",mycolor_text="black",plot_background="white") +
                              theme(axis.text.x = element_text(angle = 75, vjust = 1, hjust=1,size = size_tmp-2),
                                  axis.text.y = element_blank(),
                                  axis.title.x=element_blank(),
                                  axis.title.y=element_blank(),
                                  plot.title = element_text(size=size_tmp+1,vjust=1),
                                  plot.margin = unit(c(0.2, 0.2, 0.2, 0.2), "cm"),
                                  legend.title=element_blank(),
                                  legend.spacing.x = unit(0, 'cm'),
                                  legend.position=c("top"),
                                  legend.background = element_blank(),
                                  strip.text = element_text(size = size_tmp-1),
                                  legend.box.background = element_rect(colour = "grey60"),
                                  legend.spacing.y = unit(-.1, "mm"),
                                  legend.key = element_rect(colour = 'grey98', fill = 'grey98'),
                                  legend.key.size = unit(0.5, "cm"),
                                  legend.key.height = unit(0, "cm"),
                                  legend.text.align = 0,
                                  legend.margin=margin(2,2,2,2),
                                  legend.box.spacing = unit(3, "pt"),
                                  legend.box.margin=margin(0,0,0,0),
                                  legend.text=element_text(size=size_tmp-2))
    
    
# 7d    
  pt_plot <- egg::ggarrange(GEDI_ALS_plot+ theme(axis.title = element_text(family="Helvetica",size = 4),
                                                   strip.background.y = element_blank(),
                                                  strip.text.y = element_blank(),
                                           plot.margin=unit(c(0.2,0.2,0.2,0.2),"cm")),
                   density_plot+  theme(axis.title = element_text(size = 4),
                                         strip.background.y = element_blank(),
                                                  strip.text.y = element_blank(),
                                           plot.margin=unit(c(0.1,0,0.2,0.1),"cm")),
                   linear_dispersed_plot+ theme(axis.title = element_text(size = 4),
                                           plot.margin=unit(c(0.3,0.2,0.2,0.3),"cm")),
                          ncol = 3)

  pdf(paste0("...fig7.pdf"),height=4,width=7)
  pt_plot
  dev.off()
  