# Code for analyses for Hakkenberg et al. (In Review) ERE. May 10, 2023
# chrishakkenberg@gmail.com

#1 site beta gamma -----
  
  rm(list=ls())
  time1<-Sys.time()
  
  # variables  
    site_div_vars<-c("tree_site_gamma_SR","tree_SR_400_sitemean","tree_site_beta_BArep","plant_SR_400_sitemean","plant_site_beta_PArep","plant_site_gamma_SR")
   lidar_vars<-c("dim_tPAI","dim_max","dim_ground","config_PAIb2","config_VDRPAI","config_PAVD5","config_skew", "hetero_H1m","hetero_J","hetero_sd","hetero_Hb2")
    lidar_vars2 <- c(paste0(lidar_vars,"_sitemean"),paste0(lidar_vars,"_sitesd"))
    
  # data
    mydata<-read.csv("...NEON_plot_data.csv")
    NEON_site <- read.csv("...NEON_site_ALS_dispersed.csv")
    names(NEON_site) [-c(1:2)] <- names(NEON_site) [-c(1:2)] <- paste0(str_split(names(NEON_site) [-c(1:2)],"_",simplify=T)[,1],"_",
                                    str_split(names(NEON_site) [-c(1:2)],"_",simplify=T)[,2],"_",str_split(names(NEON_site) [-c(1:2)],"_",simplify=T)[,5])
    NEON_site2 <- NEON_site[,names(NEON_site) %in% c("siteID",lidar_vars2)]
    NEON_site3 <- NEON_site2

    GEDI_site <- read.csv("...GEDI_site_metrics.csv")
    names(GEDI_site) [-c(1:2)] <- names(GEDI_site) [-c(1:2)] <- paste0(str_split(names(GEDI_site) [-c(1:2)],"_",simplify=T)[,1],"_",
                                    str_split(names(GEDI_site) [-c(1:2)],"_",simplify=T)[,2],"_",str_split(names(GEDI_site) [-c(1:2)],"_",simplify=T)[,5])
    GEDI_site2 <- GEDI_site[,names(GEDI_site) %in% c("siteID",lidar_vars2)]
    GEDI_site3 <- GEDI_site2 

    sites_div<-read.csv("...NEON_site_div.csv")
    sites_div_mean<-aggregate(.~siteID,data= mydata[,c("siteID","longitude","latitude")],FUN=mean,na.rm=TRUE, na.action=na.pass)
    sites_div_full<-merge(sites_div_mean,sites_div,by="siteID")
  
  # model parameters
    results_list<-list();index<-1;div_var<-"plant_site_beta_PArep";site_char<-1;pred_var<-"dim_tPAI_sitesd";sensor_num<-2
    
    NEON_site3[,13:23]  <- NEON_site3[,13:23] / NEON_site3[,2:12]
    GEDI_site3[,13:23]  <- GEDI_site3[,13:23] / GEDI_site3[,2:12]

    progress.bar <- create_progress_bar("text")
    progress.bar$init(2*length(site_div_vars)*length(lidar_vars2))
    
    for (sensor_num in 1:2){
      
      if( sensor_num==1 ) {tmp_data<-merge(sites_div_full,GEDI_site3,by="siteID");sensor<-"GEDI"}
      if( sensor_num==2 ) {tmp_data<-merge(sites_div_full,NEON_site3,by="siteID");sensor<-"NEON"}
      
      for(div_var in site_div_vars){
        for (pred_var in lidar_vars2){
          progress.bar$step()
  
          tmp<-tmp_data[,c(div_var,pred_var,"siteID","longitude","latitude")]
          tmp2<-tmp[complete.cases(tmp),]
          names(tmp2)[1:2]<-c("div_var","pred_var")
          if(grepl("SR",div_var,fixed = TRUE)){tmp2$div_var<-log1p(tmp2$div_var)}
          
          tmp3<-outlier_removal_cols_withheld(tmp2,z=3,3:5)
          tmp3<-tmp3[which(complete.cases(tmp3)),]
          tmp3[,1:2]<-scale(tmp3[,1:2])

          # 1 one pred GLS
            skip_to_next  <- skip_to_next2 <-  FALSE
            tryCatch( lm1<-gls(div_var ~ pred_var,correlation=corExp(form=~longitude+latitude,nugget = TRUE), data = tmp3,control = glsControl(opt='optim',  msVerbose=F)) , error = function(e) {skip_to_next <<- TRUE})
            if(skip_to_next) {  tryCatch( lm1<-gls(div_var ~ pred_var,correlation=corExp(form=~longitude+latitude,nugget = TRUE), data = tmp3) , error = function(e) {skip_to_next2 <<- TRUE}) }
            if(skip_to_next2){next}
    
            GLS_R2_1p <- cor(tmp3$div_var,predict(lm1))^2 
            results<-as.data.frame(summary(lm1)$tTable)[2,]
        
            results$lowC<-results[1,1]-results[1,2]*1.96
            results$hiC<-results[1,1]+results[1,2]*1.96
            results<- results[c(5,1,6)]
            names(results) <- c("lCI","mCI","hCI")
            
            results$sig <- "nonsig"
            if ( (results[,"lCI"]<0 & results[,"hCI"]<0) | (results[,"lCI"]>0 & results[,"hCI"]>0) ) {results$sig <- "sig"}

          # 2 additive model
            pred_sd_mean<-lidar_vars2[lidar_vars2 %ilike% paste(str_split(pred_var,"_",simplify=T)[,1],str_split(pred_var,"_",simplify=T)[,2],sep="_")]
            tmp3<-tmp_data[,c(div_var,pred_sd_mean,"siteID","longitude","latitude")]
            tmp4<-tmp3[complete.cases(tmp3),]
            names(tmp4)[1:3]<-c("div_var","pred_mean","pred_sd")
            
            if(grepl("SR",div_var,fixed = TRUE)){tmp4$div_var<-log1p(tmp4$div_var)}
            tmp4[,1:3]<-scale(tmp4[,1:3])
      
            skip_to_next  <- skip_to_next2 <-  FALSE
            tryCatch( lm4<-gls(div_var ~ pred_mean*pred_sd,correlation=corExp(form=~longitude+latitude,nugget = TRUE), data = tmp4,control = glsControl(opt='optim',  msVerbose=F)) , error = function(e) {skip_to_next <<- TRUE})
            if(skip_to_next) {  tryCatch( lm4<-gls(div_var ~ pred_mean*pred_sd,correlation=corExp(form=~longitude+latitude,nugget = TRUE), data = tmp4) , error = function(e) {skip_to_next2 <<- TRUE}) }
            if(skip_to_next2){next}
      
            GLS_R2_2p<-cor(tmp4$div_var,predict(lm4))^2 

            out_df <- cbind(sensor,div_var,pred_var,GLS_R2_1p,results,GLS_R2_2p) 
            
            results_list[[index]]<-out_df
            index<-index+1
        }
      }
    }
  
  results_mat<-do.call(rbind,results_list);head(results_mat)

# 2 - plot alpha div~strct Poisson and NB  -------
  
  rm(list=ls())
  
  # vars
    div_vars<-c("tree_SR_400","plant_SR_400","tree_D_400","plant_D_400")
   lidar_vars<-c("dim_tPAI","dim_max","dim_ground","config_PAIb2","config_VDRPAI","config_PAVD5","config_skew", "hetero_H1m","hetero_J","hetero_sd","hetero_Hb2")

      myscales <- c(200,400,700,1100,1600,2200,2900,3700,4600,5600)
      myaggs<-c("mean","sd")
      seedLength<-3
      results_list<-list();index<-1;
          
  # strct
    load("...all_plot_strct.r")
    sites <- unique(substr(input_data_list[[9]]$plotID,1,4))
    
  # div + geo
    plot_data<-read.csv("...NEON_plot_data.csv")
    plot_data<- plot_data[substr(plot_data$plotID,1,4) %in% sites,c("plotID","longitude","latitude",div_vars)]

    
  # start subsets 1-5
    names(input_data_list)
    div_var<-"plant_SR_400";lidar_var<-"dim_tPAI";myagg<-"mean";myscale<-6400;subset<-1
    progress.bar <- create_progress_bar("text")
    progress.bar$init (5*length(div_vars)*length(lidar_vars))

    for (subset in 1:5){

      tmp <- input_data_list[[subset]]
      tmp2 <- merge(plot_data,tmp,by="plotID")

    for (div_var in div_vars){
      for (lidar_var in lidar_vars){
        progress.bar$step()

        tmp3 <- tmp2[,c(div_var,lidar_var,"longitude","latitude","plotID")]
        tmp3$siteID <- substr(tmp3$plotID,1,4)
        tmp3<-tmp3[complete.cases(tmp3),]
        tmp4<-tmp3[tmp3$siteID %in%names(which(table(tmp3$siteID)>9)),]
        tmp5<-outlier_removal_cols_withheld(tmp4,z=3,c(1,3:6))  #@@
        tmp5<-tmp5[complete.cases(tmp5),]
        tmp5[,2] <- scale(tmp5[,2])
        names(tmp5)[1:2] <- c("div_var","strct_var")
        
        # dispersion tests
          glm_tmp <- glm(div_var ~ strct_var + siteID , data=tmp5,family=poisson)
          dispersion <- AER::dispersiontest(glm_tmp)
          
          if (dispersion$p.value<0.05){
            model_output <- glmmPQL(div_var ~ strct_var,random=~1|siteID,data=tmp5,family=poisson,correlation=corExp(form=~longitude+latitude,nugget = TRUE),control = lmeControl(msMaxIter = 1000, msMaxEval = 1000))
          } else{
            m0 <- glm.nb(div_var ~ strct_var + siteID , data=tmp5)
            theta<-m0$theta
            model_output <- glmmPQL(div_var ~ strct_var,random=~1|siteID,data=tmp5,family=negative.binomial(theta),correlation=corExp(form=~longitude+latitude,nugget = TRUE),control = lmeControl(msMaxIter = 1000, msMaxEval = 1000))
          }

        results<-as.data.frame(summary(model_output)$tTable)
        results$lCI<-results[,1]-results[,2]*1.96
        results$hCI<-results[,1]+results[,2]*1.96
        results2 <- results[2,c(6,1,7)]

        results2$sig <- "nonsig"
        if ( (results2[,"lCI"]<0 & results2[,"hCI"]<0) | (results2[,"lCI"]>0 & results2[,"hCI"]>0) ) {results2$sig <- "sig"}

      # output
        sensor <- "NEON"
        myscale<-str_split(names(input_data_list), "_",simplify = TRUE)[subset,3]
        myagg<-"mean"
        out_df <- cbind(sensor,myscale,myagg,div_var,lidar_var,results2) 

        results_list[[index]] <- out_df
        index<-index+1
      } # end lidar loop
    } # end div loop
  } # end subset loop


  # do for all other subsets
    myscale<-1600;myagg<-"mean";div_var<-"tree_SR_400";lidar_var<-"hetero_J";subset<-9
        
    progress.bar <- create_progress_bar("text")
    progress.bar$init (length(div_vars)*length(lidar_vars)*4*length(myaggs)*length(myscales))
    for (subset in 6:9){

      tmp <- input_data_list[[subset]]
      tmp2 <- merge(plot_data,tmp,by="plotID")

      for (div_var in div_vars){
        for (lidar_var in lidar_vars){
          for (myscale in myscales){
            for (myagg in myaggs){
              progress.bar$step()
            
              tmp3 <- tmp2[tmp2$scale==myscale & tmp2$agg==myagg,c(div_var,lidar_var,"longitude","latitude","plotID")] 
              tmp3$siteID <- substr(tmp3$plotID,1,4)
              tmp3<-tmp3[complete.cases(tmp3),]
              tmp4<-tmp3[tmp3$siteID %in%names(which(table(tmp3$siteID)>9)),]
              tmp5<-outlier_removal_cols_withheld(tmp4,z=3,c(3:6))  #@@
              tmp5<-tmp5[complete.cases(tmp5),]
              tmp5[,2] <- scale(tmp5[,2])
              names(tmp5)[1:2] <- c("div_var","strct_var")

            # dispersion tests
              glm_tmp <- glm(div_var ~ strct_var + siteID , data=tmp5,family=poisson)
              dispersion <- AER::dispersiontest(glm_tmp)
              
              if (dispersion$p.value<0.05){
                model_output <- glmmPQL(div_var ~ strct_var,random=~1|siteID,data=tmp5,family=poisson,correlation=corExp(form=~longitude+latitude,nugget = TRUE),control = lmeControl(msMaxIter = 1000, msMaxEval = 1000))
              } else{
                m0 <- glm.nb(div_var ~ strct_var + siteID , data=tmp5)
                theta<-m0$theta
                model_output <- glmmPQL(div_var ~ strct_var,random=~1|siteID,data=tmp5,family=negative.binomial(theta),correlation=corExp(form=~longitude+latitude,nugget = TRUE),control = lmeControl(msMaxIter = 1000, msMaxEval = 1000))
              }

              results<-as.data.frame(summary(model_output)$tTable)
              results$lCI<-results[,1]-results[,2]*1.96
              results$hCI<-results[,1]+results[,2]*1.96
              results2 <- results[2,c(6,1,7)]
              
              results2$sig <- "nonsig"
              if ( (results2[,"lCI"]<0 & results2[,"hCI"]<0) | (results2[,"lCI"]>0 & results2[,"hCI"]>0) ) {results2$sig <- "sig"}

              sensor <- names(input_data_list)[[subset]]
              
              out_df <- cbind(sensor,myscale,myagg,div_var,lidar_var,results2) # GLM_R2

              results_list[[index]] <- out_df

              index<-index+1
            } # end agg
          } # end scale
        } # end lidar
      } # end div
    } # end subset

    results_mat<-do.call(rbind.fill,results_list);head(results_mat)
    results_mat$myscale <- as.numeric(results_mat$myscale)
    
# 3. ecoregional analyses (17min) ----------  

  rm(list=ls())

  # vars
      div_vars<-c("tree_D_400","plant_D_400","tree_SR_400","plant_SR_400") 
      lidar_vars<-c("dim_max","dim_tPAI","hetero_H1m","hetero_J","config_PAIb2","config_VDRPAI")
      myscales <- c(100,200,400,700,1100,1600,2200,2900,3700,4600,5600)

  # strct
    load("...all_plot_strct.r")
    sites <- unique(substr(input_data_list[[8]]$plotID,1,4))
    er<-read.csv("...NEON_site_lle.csv")
    
    er[er$siteID=="SJER","epa_merge"] <- "NW Mountains"
    
  # div + geo
    plot_data<-read.csv("...NEON_plot_data.csv")
    plot_data<- plot_data[substr(plot_data$plotID,1,4) %in% sites,c("siteID","plotID","longitude","latitude",div_vars)]

    plot_data2 <- merge(plot_data,er[,c("siteID","epa_merge")],by="siteID",all.x=T)
    
    plot_data2[345:355,]
    plot_data2$epa_merge
    ecoregions <- unique(plot_data2$epa_merge)
    
  # parameters and progress
    div_var<-"plant_D_400";lidar_var<-"dim_tPAI";results_list<-list();index<-1;subset<-1;ecoregion<-"NW Mountains"
    progress.bar <- create_progress_bar("text")
    progress.bar$init (5*length(ecoregions)*length(div_vars)*length(lidar_vars))
 
    for (subset in 1:5){
      
      tmp <- input_data_list[[subset]]
      tmp2 <- merge(plot_data2,tmp,by="plotID")
      
      for (ecoregion in ecoregions){  
        for (div_var in div_vars){
          for (lidar_var in lidar_vars){
            progress.bar$step()
        
            # wrangle
              tmp3 <- tmp2[tmp2$epa_merge==ecoregion,c(div_var,lidar_var,"siteID","longitude","latitude","plotID")]
              tmp4<-tmp3[complete.cases(tmp3),]
              tmp5<-tmp4[tmp4$siteID %in%names(which(table(tmp4$siteID)>9)),]
              names(tmp5)[1:2] <- c("div_var","strct_var")
              tmp5[,"strct_var"] <- scale(tmp5[,"strct_var"])
              if ( (nrow(tmp5)<10) | (length(unique(tmp5$siteID)) < 2) ) {next}
              
              if (div_var%in%c("tree_D_400","plant_D_400")){
                
                skip_to_next  <- skip_to_next2 <-  FALSE
                tryCatch(model_output<-gls(div_var ~ strct_var,correlation=corExp(form=~longitude+latitude,nugget = TRUE), data = tmp5,control = glsControl(opt='optim',  msVerbose=F)) , error = function(e) {skip_to_next <<- TRUE})
                if(skip_to_next) {next}
   
              } else {
                
                # dispersion tests
                glm_tmp <- glm(div_var ~ strct_var + siteID , data=tmp5,family=poisson)
                dispersion <- AER::dispersiontest(glm_tmp)
    
                 if (dispersion$p.value<0.05) {
                   skip_to_next  <-   FALSE
                   tryCatch( model_output <- glmmPQL(div_var ~ strct_var,random=~1|siteID,data=tmp5,family=poisson,correlation=corExp(form=~longitude+latitude,nugget = TRUE),control = lmeControl(msMaxIter = 1000, msMaxEval = 1000,opt='optim')), error = function(e) {skip_to_next <<- TRUE})
                   
                   if(skip_to_next) {  
                     m0 <- glm.nb(div_var ~ strct_var + siteID , data=tmp5)
                     theta<-m0$theta
                     model_output <- glmmPQL(div_var ~ strct_var,random=~1|siteID,data=tmp5,family=negative.binomial(theta),correlation=corExp(form=~longitude+latitude,nugget = TRUE),control = lmeControl(msMaxIter = 1000, msMaxEval = 1000,opt='optim'))
                   } 
                   } else{
                     skip_to_next2  <-   FALSE
                     m0 <- glm.nb(div_var ~ strct_var + siteID , data=tmp5)
                     theta<-m0$theta
                     tryCatch(model_output <- glmmPQL(div_var ~ strct_var,random=~1|siteID,data=tmp5,family=negative.binomial(theta),correlation=corExp(form=~longitude+latitude,nugget = TRUE),control = lmeControl(msMaxIter = 1000, msMaxEval = 1000,opt='optim')), error = function(e) {skip_to_next <<- TRUE})
                     if(skip_to_next2) {  
                       model_output <- glmmPQL(div_var ~ strct_var,random=~1|siteID,data=tmp5,family=poisson,correlation=corExp(form=~longitude+latitude,nugget = TRUE),control = lmeControl(msMaxIter = 1000, msMaxEval = 1000,opt='optim'))
                     }
                   }
              } #end SR else
              
              results<-as.data.frame(summary(model_output)$tTable)
              results$lCI<-results[,1]-results[,2]*1.96
              results$hCI<-results[,1]+results[,2]*1.96
              
              if (div_var%in%c("tree_D_400","plant_D_400")){
                        results2 <- results[2,c(5,1,6)] 
              } else { results2 <- results[2,c(6,1,7)] }
                
              results2$sig <- "nonsig"
              if ( (results2[,"lCI"]<0 & results2[,"hCI"]<0) | (results2[,"lCI"]>0 & results2[,"hCI"]>0) ) {results2$sig <- "sig"}

            # output
              sensor <- "NEON"
              myscale<-str_split(names(input_data_list), "_",simplify = TRUE)[subset,3]
              out_df <- cbind(sensor,ecoregion,myscale,div_var,lidar_var,results2) # spRF_R2_1pred,spRFcv
      
              results_list[[index]] <- out_df
              index<-index+1
              } # end lidar loop
            } # end div loop
          } # end ecoregion loop
        } # end subset loop
    
  # do for all other subsets
    myscale<-5600;div_var<-"tree_SR_400";lidar_var<-"dim_max";subset<-8;ecoregion<-"Tropical Wet Forests"
    progress.bar <- create_progress_bar("text")
    progress.bar$init (4*length(div_vars)*length(lidar_vars)*length(ecoregions)*length(myscales)) 
    
    for (subset in 8:9){

      tmp <- input_data_list[[subset]]
      tmp2 <- merge(plot_data2,tmp,by="plotID")

      for (ecoregion in ecoregions){  
        for (div_var in div_vars){
          for (lidar_var in lidar_vars){
            for (myscale in myscales){
              progress.bar$step()

              # wrangle
                tmp3 <- tmp2[tmp2$scale==myscale & tmp2$agg=="mean" & tmp2$epa_merge==ecoregion,c(div_var,lidar_var,"siteID","longitude","latitude","plotID")]
                tmp4<-tmp3[complete.cases(tmp3),]
                tmp5<-tmp4[tmp4$siteID %in%names(which(table(tmp4$siteID)>9)),]
                names(tmp5)[1:2] <- c("div_var","strct_var")
                tmp5[,"strct_var"] <- scale(tmp5[,"strct_var"])
                if ( (nrow(tmp5)<10) | (length(unique(tmp5$siteID)) < 2) ) {next}
                
                if (div_var%in%c("tree_D_400","plant_D_400")){
                  
                    skip_to_next  <- skip_to_next2 <-  FALSE
                    tryCatch(model_output<-gls(div_var ~ strct_var,correlation=corExp(form=~longitude+latitude,nugget = TRUE), data = tmp5,control = glsControl(opt='optim',  msVerbose=F)) , error = function(e) {skip_to_next <<- TRUE})
                    if(skip_to_next) {next}
                           
                } else {
                
                # dispersion tests
                  glm_tmp <- glm(div_var ~ strct_var + siteID , data=tmp5,family=poisson)
                  dispersion <- AER::dispersiontest(glm_tmp)
            
                  if (dispersion$p.value<0.05) {
                    skip_to_next  <-   FALSE
                    tryCatch( model_output <- glmmPQL(div_var ~ strct_var,random=~1|siteID,data=tmp5,family=poisson,correlation=corExp(form=~longitude+latitude,nugget = TRUE),control = lmeControl(msMaxIter = 1000, msMaxEval = 1000,opt='optim')), error = function(e) {skip_to_next <<- TRUE})
                      if(skip_to_next) {  
                        m0 <- glm.nb(div_var ~ strct_var + siteID , data=tmp5)
                        theta<-m0$theta
                        skip_to_next2  <-   FALSE
                          tryCatch(model_output <- glmmPQL(div_var ~ strct_var,random=~1|siteID,data=tmp5,family=negative.binomial(theta),correlation=corExp(form=~longitude+latitude,nugget = TRUE),control = lmeControl(msMaxIter = 1000, msMaxEval = 1000,opt='optim')), error = function(e) {skip_to_next2 <<- TRUE})
                           if(skip_to_next2) {next}
                        } 
                  } else{
                    skip_to_next3  <-   FALSE
                    m0 <- glm.nb(div_var ~ strct_var + siteID , data=tmp5)
                    theta<-m0$theta
                    tryCatch(model_output <- glmmPQL(div_var ~ strct_var,random=~1|siteID,data=tmp5,family=negative.binomial(theta),correlation=corExp(form=~longitude+latitude,nugget = TRUE),control = lmeControl(msMaxIter = 1000, msMaxEval = 1000,opt='optim')), error = function(e) {skip_to_next3 <<- TRUE})
                      if(skip_to_next3) {  
                        skip_to_next4  <-   FALSE
                        tryCatch(model_output <- glmmPQL(div_var ~ strct_var,random=~1|siteID,data=tmp5,family=poisson,correlation=corExp(form=~longitude+latitude,nugget = TRUE),control = lmeControl(msMaxIter = 1000, msMaxEval = 1000,opt='optim')), error = function(e) {skip_to_next4 <<- TRUE})
                        if(skip_to_next4) {next}
                      }
                  }
                }# end SR else
  
                results<-as.data.frame(summary(model_output)$tTable)
                results$lCI<-results[,1]-results[,2]*1.96
                results$hCI<-results[,1]+results[,2]*1.96
                
                
               if (div_var%in%c("tree_D_400","plant_D_400")){
              results2 <- results[2,c(5,1,6)] 
               } else { results2 <- results[2,c(6,1,7)] }
                
                results2$sig <- "nonsig"
                if ( (results2[,"lCI"]<0 & results2[,"hCI"]<0) | (results2[,"lCI"]>0 & results2[,"hCI"]>0) ) {results2$sig <- "sig"}

              # output
                sensor <- names(input_data_list)[[subset]]
                out_df <- cbind(sensor,myscale,ecoregion,div_var,lidar_var,results2) 
                results_list[[index]] <- out_df
                index<-index+1
            } # end myscale
          } # end lidar_vars
        } # end div_vars
      } # end ecoregions
    } # end subsets

    results_mat<-do.call(rbind.fill,results_list);head(results_mat)
    results_mat$myscale <- as.numeric(results_mat$myscale)
